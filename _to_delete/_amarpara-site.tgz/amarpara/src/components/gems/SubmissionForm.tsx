"use client";

import { useState } from "react";
import { UploadCloud } from "@/components/ui/icons";

const CATEGORIES = ["Food", "Places", "Traditions", "Events", "Cuisines", "Institutions"];

const FIELD =
  "h-[52px] w-full rounded-[8px] border border-line bg-white px-4 font-body text-[15px] text-navy placeholder:text-slate focus:border-pink focus:outline-none";

function Label({ children }: { children: React.ReactNode }) {
  return <span className="font-display text-[16px] font-bold text-navy">{children}</span>;
}

/** form-card — Figma 95:341. Client-side only for now; wire to an API later. */
export function SubmissionForm() {
  const [fileName, setFileName] = useState<string | null>(null);

  return (
    <form
      className="flex w-[800px] flex-col gap-8 rounded-[20px] bg-white p-12 shadow-[0_12px_16px_rgba(27,42,74,0.06)]"
      onSubmit={(event) => event.preventDefault()}
    >
      <label className="flex w-[340px] flex-col gap-2">
        <Label>Name Your Para</Label>
        <input className={FIELD} placeholder="e.g. Bagbazar, Shyambazar, Ballygunge..." />
      </label>

      <label className="flex w-[340px] flex-col gap-2">
        <Label>Location</Label>
        <input className={FIELD} placeholder="e.g. Bagbazar, Shyambazar, Ballygunge..." />
      </label>

      <label className="flex w-[340px] flex-col gap-2">
        <Label>Name Your Hidden Gem</Label>
        <input className={FIELD} placeholder="e.g. Paramount Sherbets, Mallick Ghat..." />
      </label>

      <label className="flex w-[340px] flex-col gap-2">
        <Label>Category</Label>
        <select className={FIELD} defaultValue="">
          <option value="" disabled>
            Choose a category...
          </option>
          {CATEGORIES.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </label>

      <label className="flex w-full flex-col gap-2">
        <Label>Describe Your Hidden Gem</Label>
        <textarea
          rows={5}
          className="h-[140px] w-full resize-none rounded-[8px] border border-line bg-white p-4 font-body text-[15px] leading-[1.5] text-navy placeholder:text-slate focus:border-pink focus:outline-none"
          placeholder="Share the story of your para — what makes this place special? Tell us about a hidden sweet shop, a forgotten lane, a legendary adda spot, or an unsung local hero..."
        />
      </label>

      <div className="flex w-full flex-col gap-3">
        <Label>Upload Photo / Video</Label>
        <label className="flex cursor-pointer flex-col items-center justify-center gap-3 rounded-[12px] border-2 border-dashed border-pink bg-cream/30 p-8 text-center">
          <input
            type="file"
            accept="image/jpeg,image/png,video/mp4"
            className="sr-only"
            onChange={(event) => setFileName(event.target.files?.[0]?.name ?? null)}
          />
          <span className="flex size-12 items-center justify-center rounded-full bg-pink/8 text-pink">
            <UploadCloud />
          </span>
          <span className="font-display text-[18px] font-extrabold text-navy">
            {fileName ?? "Share Your Memory"}
          </span>
          <span className="w-[400px] font-body text-[14px] text-slate">
            Drag &amp; drop or click to upload photos or videos (max 10MB)
          </span>
          <span className="font-ui text-[11px] font-bold uppercase text-slate/60">
            Supported formats: JPG, PNG, MP4
          </span>
        </label>
      </div>

      <div className="flex justify-center pt-4">
        <button
          type="submit"
          className="btn-3d inline-flex h-14 w-[300px] items-center justify-center rounded-[4px] bg-yellow font-display text-[16px] font-extrabold uppercase text-navy hover:-translate-y-[2px] hover:shadow-[6px_6px_0_0_var(--color-navy)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0_0_var(--color-navy)]"
        >
          Submit your gem
        </button>
      </div>
    </form>
  );
}
