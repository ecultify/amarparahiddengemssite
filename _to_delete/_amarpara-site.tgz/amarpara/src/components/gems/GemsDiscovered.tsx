"use client";

import { useRef } from "react";
import { Button3D } from "@/components/ui/Button3D";
import { GemCard } from "@/components/home/GemCard";
import { ChevronLeft, ChevronRight } from "@/components/ui/icons";
import { DISCOVERED_GEMS, GEM_COUNT } from "@/data/site";

type Theme = "cream" | "cyan";

const THEMES: Record<Theme, { section: string; title: string; arrow: string }> = {
  // Participate page — Figma 95:124.
  cream: { section: "bg-cream", title: "text-black", arrow: "border-yellow text-navy" },
  // Submission page — Figma 95:362.
  cyan: { section: "bg-cyan", title: "text-white", arrow: "border-white text-navy" },
};

const CARD_STRIDE = 304;

/**
 * "Gems Already Discovered" — the community directory block shared by the
 * participate and submit pages. Identical structure, two colourways.
 */
export function GemsDiscovered({ theme = "cream" }: { theme?: Theme }) {
  const trackRef = useRef<HTMLDivElement>(null);
  const tone = THEMES[theme];
  const percent = Math.round((GEM_COUNT.discovered / GEM_COUNT.total) * 100);

  const scroll = (direction: -1 | 1) =>
    trackRef.current?.scrollBy({ left: direction * CARD_STRIDE, behavior: "smooth" });

  return (
    <section className={`relative w-full overflow-hidden ${tone.section} pt-[53px] pb-[80px]`}>
      <div className="mx-auto max-w-[1440px] px-20">
        <div className="flex flex-col items-center gap-5">
          <div className="flex w-full flex-col items-center gap-3 text-center">
            <p className="font-display text-[14px] font-black uppercase tracking-[0.08em] text-yellow">
              Community Directory
            </p>
            <h2 className={`font-display text-[42px] leading-tight font-black ${tone.title}`}>
              Gems Already Discovered
            </h2>
          </div>

          <div className="flex w-[520px] flex-col items-center gap-4 rounded-[16px] border border-white/10 bg-red p-6">
            <div className="flex w-full items-center justify-between">
              <span className="font-display text-[16px] font-extrabold text-yellow">Mapping progress</span>
              <span className="font-display text-[18px] font-black text-white">
                {GEM_COUNT.discovered} / {GEM_COUNT.total} GEMS
              </span>
            </div>
            <div className="h-[10px] w-full overflow-hidden rounded-full bg-white/40">
              <div className="h-full rounded-full bg-yellow" style={{ width: `${percent}%` }} />
            </div>
          </div>
        </div>

        <div className="mt-14 flex items-center gap-6">
          <button
            type="button"
            aria-label="Previous gems"
            onClick={() => scroll(-1)}
            className={`flex size-12 shrink-0 items-center justify-center rounded-full border-2 bg-white ${tone.arrow}`}
          >
            <ChevronLeft className="size-5" />
          </button>

          <div ref={trackRef} className="no-scrollbar flex flex-1 gap-6 overflow-x-auto">
            {DISCOVERED_GEMS.map((gem) => (
              <GemCard key={gem.title} gem={gem} titleTone="navy" />
            ))}
          </div>

          <button
            type="button"
            aria-label="Next gems"
            onClick={() => scroll(1)}
            className={`flex size-12 shrink-0 items-center justify-center rounded-full border-2 bg-white ${tone.arrow}`}
          >
            <ChevronRight className="size-5" />
          </button>
        </div>

        <div className="mt-14 flex justify-center">
          <Button3D href="/500-gems">View all gems</Button3D>
        </div>
      </div>
    </section>
  );
}
