export type Category = "Food" | "Places" | "Traditions" | "Events" | "Cuisines";

/** Tag pill colours, straight from the Figma gem-card component. */
const TAG_STYLES: Record<Category, string> = {
  Food: "bg-pink/8 text-pink",
  Places: "bg-cyan/8 text-cyan",
  Traditions: "bg-yellow/13 text-amber",
  Events: "bg-pink/8 text-pink",
  Cuisines: "bg-cyan/8 text-cyan",
};

export function CategoryTag({ category }: { category: Category }) {
  return (
    <span
      className={`inline-flex rounded-[6px] px-[10px] py-[4px] font-ui text-[11px] font-bold uppercase ${TAG_STYLES[category]}`}
    >
      {category}
    </span>
  );
}
