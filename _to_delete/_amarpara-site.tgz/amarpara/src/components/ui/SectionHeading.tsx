import type { ReactNode } from "react";

type Props = {
  /** Small all-caps eyebrow above the title. */
  eyebrow: string;
  eyebrowClassName?: string;
  title: ReactNode;
  titleClassName?: string;
  blurb?: string;
  blurbClassName?: string;
  blurbWidth?: number;
};

/**
 * The eyebrow / display title / blurb stack repeated at the top of every
 * section in the design (Explore the Gems, Stories from the Paras, Creator
 * Trails, Articles & Features).
 */
export function SectionHeading({
  eyebrow,
  eyebrowClassName = "text-cyan",
  title,
  titleClassName = "text-ink",
  blurb,
  blurbClassName = "text-muted",
  blurbWidth = 600,
}: Props) {
  return (
    <div className="flex w-full flex-col items-center gap-3">
      <p className={`font-display text-[14px] font-extrabold uppercase tracking-[0.08em] ${eyebrowClassName}`}>
        {eyebrow}
      </p>
      <h2 className={`text-center font-display text-[42px] leading-[1.1] font-black ${titleClassName}`}>
        {title}
      </h2>
      {blurb ? (
        <p
          className={`text-center font-body text-[16px] leading-[1.5] ${blurbClassName}`}
          style={{ maxWidth: blurbWidth }}
        >
          {blurb}
        </p>
      ) : null}
    </div>
  );
}
