/* eslint-disable @next/next/no-img-element */
import type { CSSProperties } from "react";

type Props = {
  src: string;
  alt?: string;
  className?: string;
  style?: CSSProperties;
};

/**
 * Thin wrapper around <img> for Figma-exported artwork in /public/images.
 *
 * Plain <img> rather than next/image on purpose: these are fixed-size design
 * assets placed at exact coordinates, and next/image's layout wrapper fights
 * the absolute positioning the design relies on. The data-asset attribute gives
 * every asset a neutral tint so a missing export reads as a placeholder block
 * instead of a broken-image icon.
 */
export function Asset({ src, alt = "", className = "", style }: Props) {
  return <img data-asset src={src} alt={alt} className={className} style={style} />;
}
