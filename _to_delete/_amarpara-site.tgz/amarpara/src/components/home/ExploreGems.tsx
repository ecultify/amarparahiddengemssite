"use client";

import { useRef, useState } from "react";
import { Asset } from "@/components/ui/Asset";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { ChevronLeft, ChevronRight } from "@/components/ui/icons";
import { GemCard } from "@/components/home/GemCard";
import { GEMS } from "@/data/site";
import { IMG } from "@/lib/assets";

const CARD_STRIDE = 304; // 280px card + 24px gap

/** Explore the Gems of Kolkata — Figma 49:1946 + 49:1950. */
export function ExploreGems() {
  const trackRef = useRef<HTMLDivElement>(null);
  const [page, setPage] = useState(0);
  const pages = Math.max(1, GEMS.length - 3);

  const scrollBy = (direction: -1 | 1) => {
    const next = Math.min(Math.max(page + direction, 0), pages - 1);
    setPage(next);
    trackRef.current?.scrollTo({ left: next * CARD_STRIDE, behavior: "smooth" });
  };

  return (
    <section id="explore" className="relative w-full overflow-hidden bg-green">
      <Asset
        src={IMG.accentKites}
        className="pointer-events-none absolute top-[-40px] right-[-60px] h-[199px] w-[174px] object-contain opacity-90"
      />

      <div className="mx-auto max-w-[1440px] px-20 pt-[50px] pb-[60px]">
        <SectionHeading
          eyebrow="Community Submissions"
          eyebrowClassName="text-yellow"
          title="Explore the Gems of Kolkata"
          titleClassName="text-white"
          blurb="Sift through verified hidden spots, iconic sweet shops, legendary characters, and heritage architectural nooks documented by passionate citizens."
          blurbClassName="text-white"
        />

        <div className="mt-8 flex items-center gap-2">
          <button
            type="button"
            aria-label="Previous gems"
            onClick={() => scrollBy(-1)}
            className="flex size-10 items-center justify-center rounded-full border border-line bg-white text-navy disabled:opacity-40"
            disabled={page === 0}
          >
            <ChevronLeft />
          </button>
          <button
            type="button"
            aria-label="Next gems"
            onClick={() => scrollBy(1)}
            className="flex size-10 items-center justify-center rounded-full border border-line bg-white text-navy disabled:opacity-40"
            disabled={page >= pages - 1}
          >
            <ChevronRight />
          </button>
        </div>

        <div ref={trackRef} className="no-scrollbar mt-8 flex gap-6 overflow-x-auto">
          {GEMS.map((gem) => (
            <GemCard key={gem.title} gem={gem} />
          ))}
        </div>

        <div className="mt-8 flex items-center justify-center gap-2">
          {Array.from({ length: 4 }).map((_, index) => (
            <span
              key={index}
              className={`size-2 rounded-full ${index === page ? "bg-white" : "bg-white/40"}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
