import { Button3D } from "@/components/ui/Button3D";
import { Gem } from "@/components/ui/icons";
import { IMG } from "@/lib/assets";
import { GEM_COUNT } from "@/data/site";

/**
 * Hero — Figma 49:1944.
 *
 * The hero frame in Figma is a single flattened raster: headline, editorial
 * caption and collage are all baked into one image. Everything on the left is
 * rebuilt here as real text so it is selectable, translatable and indexable;
 * the collage on the right is the only part that stays an image, cropped out of
 * the flattened export so the baked-in navbar and headline are excluded.
 *
 * COLLAGE_CROP describes that crop against the 1440x801 source.
 */
const COLLAGE_CROP = {
  sourceWidth: 1440,
  sourceHeight: 801,
  left: 640,
  top: 88,
  width: 800,
  height: 713,
};

export function Hero() {
  return (
    <section className="relative w-full overflow-hidden bg-cream" style={{ height: COLLAGE_CROP.height }}>
      <div
        aria-hidden
        className="pointer-events-none absolute top-0 right-0"
        style={{
          width: COLLAGE_CROP.width,
          height: COLLAGE_CROP.height,
          backgroundImage: `url(${IMG.heroCollage})`,
          backgroundSize: `${COLLAGE_CROP.sourceWidth}px ${COLLAGE_CROP.sourceHeight}px`,
          backgroundPosition: `-${COLLAGE_CROP.left}px -${COLLAGE_CROP.top}px`,
          backgroundRepeat: "no-repeat",
        }}
      />

      <div className="relative mx-auto flex h-full max-w-[1440px] flex-col justify-center px-20">
        <h1 className="font-display text-[72px] leading-[0.98] font-black tracking-[-0.02em] text-navy uppercase">
          500 Gems.
          <br />
          One Kolkata.
        </h1>

        <p className="mt-6 max-w-[420px] font-body text-[16px] leading-[1.55] text-navy">
          Every para has a story.
          <br />
          Every story is a gem.
          <br />
          Help us discover 500 hidden gems of Kolkata.
        </p>

        <div className="mt-8 flex items-center gap-2">
          <Button3D href="/submit" className="w-[247px] px-0">
            Submit your gem
          </Button3D>
          <Button3D href="/500-gems" variant="outline" className="w-[247px] px-0">
            Explore gems
          </Button3D>
        </div>

        <div className="mt-8 flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-full bg-yellow text-navy">
            <Gem />
          </span>
          <span className="font-display text-[32px] leading-none font-black text-navy">
            {GEM_COUNT.discovered}
          </span>
          <span className="font-body text-[15px] text-navy">
            of {GEM_COUNT.total} gems discovered
          </span>
        </div>
      </div>
    </section>
  );
}
