import { Asset } from "@/components/ui/Asset";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { CREATOR_TRAILS } from "@/data/site";
import { IMG } from "@/lib/assets";

/** Creator Trails — Figma 49:2139. Five-up 240x380 mosaic. */
export function CreatorTrails() {
  return (
    <section id="creator-trails" className="relative w-full overflow-hidden bg-cream pt-[44px] pb-[100px]">
      <Asset
        src={IMG.accentHeritageWatermark}
        className="pointer-events-none absolute top-0 left-[-14px] h-[396px] w-[241px] object-contain opacity-75"
      />
      <Asset
        src={IMG.accentGolfer}
        className="pointer-events-none absolute top-[74px] left-[-36px] h-[180px] w-[170px] object-contain opacity-[0.88]"
      />
      <Asset
        src={IMG.accentKiteCreator}
        className="pointer-events-none absolute top-[80px] right-[-40px] h-[153px] w-[136px] object-contain opacity-85"
      />

      <div className="relative mx-auto max-w-[1440px] px-20">
        <SectionHeading
          eyebrow="Follow the Walk"
          eyebrowClassName="text-pink"
          title="Creator Trails"
          blurb="Join celebrated filmmakers, writers, and artists as they explore secret corners and carve custom neighborhood trails."
        />

        <div className="mt-14 flex h-[380px] gap-4">
          {CREATOR_TRAILS.map((src, index) => (
            <Asset
              key={index}
              src={src}
              alt={`Creator trail ${index + 1}`}
              className="h-[380px] w-[240px] shrink-0 rounded-[16px] object-cover"
            />
          ))}
        </div>

        <div className="mt-14 flex items-center justify-center gap-2">
          {Array.from({ length: 5 }).map((_, index) => (
            <span
              key={index}
              className={`size-2 rounded-full ${index === 0 ? "bg-pink" : "bg-navy/15"}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
