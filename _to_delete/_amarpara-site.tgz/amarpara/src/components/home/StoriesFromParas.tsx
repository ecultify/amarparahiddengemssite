"use client";

import { useState } from "react";
import { Asset } from "@/components/ui/Asset";
import { Button3D } from "@/components/ui/Button3D";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { ArrowLeft, ArrowRight } from "@/components/ui/icons";
import { STORIES } from "@/data/site";
import { IMG } from "@/lib/assets";

/**
 * Stories from the Paras — Figma 49:2023.
 * A five-up coverflow: the centre card is large with a pink border and a
 * FEATURED STORY badge, flanked by 220px and 180px cards at reduced opacity.
 */
const SLOT_STYLES = [
  { width: 180, height: 260, radius: 12, opacity: 0.5, scrim: 0.4, pad: 16, name: 16, para: 12 },
  { width: 220, height: 300, radius: 16, opacity: 0.8, scrim: 0.3, pad: 20, name: 18, para: 13 },
  { width: 280, height: 360, radius: 20, opacity: 1, scrim: 0.25, pad: 24, name: 22, para: 14 },
  { width: 220, height: 300, radius: 16, opacity: 0.8, scrim: 0.3, pad: 20, name: 18, para: 13 },
  { width: 180, height: 260, radius: 12, opacity: 0.5, scrim: 0.4, pad: 16, name: 16, para: 12 },
];

export function StoriesFromParas() {
  const [active, setActive] = useState(2);
  const featured = STORIES[active];

  // Rotate the deck so the active story always sits in the centre slot.
  const ordered = SLOT_STYLES.map((slot, index) => ({
    slot,
    story: STORIES[(active + index - 2 + STORIES.length) % STORIES.length],
    isCentre: index === 2,
  }));

  const step = (direction: -1 | 1) =>
    setActive((current) => (current + direction + STORIES.length) % STORIES.length);

  return (
    <section id="stories" className="relative w-full overflow-hidden bg-cream-alt">
      <Asset
        src={IMG.accentStatue}
        className="pointer-events-none absolute top-[100px] left-[-70px] h-[280px] w-[180px] object-contain opacity-[0.88]"
      />
      <Asset
        src={IMG.accentTemple}
        className="pointer-events-none absolute right-[-10px] bottom-[40px] h-[300px] w-[180px] scale-x-[-1] object-contain opacity-85"
      />
      <Asset
        src={IMG.accentAutoRickshaw}
        className="pointer-events-none absolute top-[540px] left-[143px] h-[107px] w-[142px] object-contain opacity-90"
      />
      <Asset
        src={IMG.accentBirds}
        className="pointer-events-none absolute top-[60px] left-[900px] h-[60px] w-[120px] object-contain opacity-70"
      />

      <div className="relative mx-auto max-w-[1440px] px-20 pt-[100px] pb-[90px]">
        <SectionHeading
          eyebrow="Chronicles of Kolkata"
          eyebrowClassName="text-cyan"
          title="Stories from the Paras"
          blurb="Real people. Real memories. Authentic life snippets that breathe soul into the historic streets."
        />

        <div className="mt-[29px] flex w-full items-center justify-center gap-6">
          <button
            type="button"
            aria-label="Previous story"
            onClick={() => step(-1)}
            className="flex size-12 shrink-0 items-center justify-center rounded-full border-2 border-pink bg-white text-pink"
          >
            <ArrowLeft />
          </button>

          <div className="flex items-center justify-center gap-4">
            {ordered.map(({ slot, story, isCentre }, index) => (
              <button
                key={`${story.name}-${index}`}
                type="button"
                onClick={() => setActive(STORIES.indexOf(story))}
                style={{
                  width: slot.width,
                  height: slot.height,
                  borderRadius: slot.radius,
                  opacity: slot.opacity,
                }}
                className={`relative flex shrink-0 flex-col justify-between overflow-hidden text-left ${
                  isCentre
                    ? "border-4 border-pink shadow-[0_16px_32px_0_rgba(27,42,74,0.25)]"
                    : ""
                }`}
              >
                <Asset src={story.image} alt={story.name} className="absolute inset-0 size-full object-cover" />
                <span
                  className="absolute inset-0"
                  style={{ backgroundColor: `rgba(27,42,74,${slot.scrim})` }}
                />
                <span className="relative flex h-full w-full flex-col justify-between" style={{ padding: slot.pad }}>
                  {isCentre ? (
                    <span className="inline-flex w-fit rounded-full bg-red px-3 py-1 font-ui text-[11px] font-extrabold text-white uppercase">
                      Featured Story
                    </span>
                  ) : (
                    <span className="block h-[10px]" />
                  )}
                  <span className="flex flex-col gap-1">
                    <span
                      className="font-display font-black text-white"
                      style={{ fontSize: slot.name }}
                    >
                      {story.name}
                    </span>
                    <span className="font-ui font-bold text-pink" style={{ fontSize: slot.para }}>
                      {story.para}
                    </span>
                  </span>
                </span>
              </button>
            ))}
          </div>

          <button
            type="button"
            aria-label="Next story"
            onClick={() => step(1)}
            className="flex size-12 shrink-0 items-center justify-center rounded-full border-2 border-pink bg-white text-pink"
          >
            <ArrowRight />
          </button>
        </div>

        <blockquote className="mx-auto mt-[29px] flex w-[680px] flex-col items-center gap-3 text-center">
          <p className="font-ui text-[16px] leading-[26px] text-slate">{featured.quote}</p>
          <footer className="font-display text-[16px] font-bold text-red">{featured.attribution}</footer>
        </blockquote>

        <div className="mt-[29px] flex items-center justify-center gap-2">
          {Array.from({ length: 10 }).map((_, index) => (
            <span
              key={index}
              className={`size-2 rounded-full ${index === active ? "bg-pink" : "bg-navy/15"}`}
            />
          ))}
        </div>

        <div className="mt-[29px] flex justify-center">
          <Button3D href="/submit" className="w-[320px] px-0">
            Share your story
          </Button3D>
        </div>
      </div>
    </section>
  );
}
