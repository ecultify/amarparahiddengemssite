import { Asset } from "@/components/ui/Asset";
import { IMG } from "@/lib/assets";
import { ARTICLES_ROW_ONE, ARTICLES_ROW_TWO, type Article } from "@/data/site";

/** article-card — Figma 49:2098. 320x200, 50% black scrim, title bottom-left. */
function ArticleCard({ article }: { article: Article }) {
  return (
    <article className="relative h-[200px] w-[320px] shrink-0 overflow-hidden rounded-[12px]">
      <Asset src={article.image} alt={article.title} className="absolute inset-0 size-full object-cover" />
      <div className="absolute inset-0 bg-black/50" />
      <div className="relative flex h-full flex-col justify-end p-5">
        <h3 className="font-display text-[18px] leading-tight font-extrabold text-white">
          {article.title}
        </h3>
      </div>
    </article>
  );
}

/** Articles & Features — Figma 49:2090. Two staggered rows that bleed right. */
export function ArticlesFeatures() {
  return (
    <section id="articles" className="relative w-full overflow-hidden bg-yellow pt-[38px] pb-[100px]">
      <Asset
        src={IMG.accentArch}
        className="pointer-events-none absolute top-[60px] right-[-60px] h-[220px] w-[130px] object-contain opacity-[0.88]"
      />

      <div className="mx-auto flex max-w-[1440px] flex-col items-center gap-3 px-20">
        <p className="font-display text-[14px] font-black uppercase tracking-[0.08em] text-pink">
          Articles &amp; Features
        </p>
        <h2 className="text-center font-display text-[40px] leading-tight font-black text-white">
          Deep dives into Kolkata&apos;s most fascinating paras.
        </h2>
        <p className="max-w-[788px] text-center font-body text-[16px] text-muted">
          Real people. Real memories. Authentic life snippets that breathe soul into the historic streets.
        </p>
      </div>

      <div className="mt-14 flex flex-col gap-7">
        <div className="flex gap-5 pl-20">
          {ARTICLES_ROW_ONE.map((article) => (
            <ArticleCard key={article.title} article={article} />
          ))}
        </div>
        <div className="flex gap-5 pl-40">
          {ARTICLES_ROW_TWO.map((article) => (
            <ArticleCard key={article.title} article={article} />
          ))}
        </div>
      </div>
    </section>
  );
}
