import Link from "next/link";
import { Asset } from "@/components/ui/Asset";
import { IMG } from "@/lib/assets";
import { Facebook, Instagram, Twitter } from "@/components/ui/icons";

const COLUMN_ONE = [
  { label: "About", href: "/about" },
  { label: "Exhibitions", href: "/exhibitions" },
  { label: "Participate", href: "/participate" },
  { label: "500 Gems", href: "/500-gems" },
];

const COLUMN_TWO = [
  { label: "Contact", href: "/contact" },
  { label: "Privacy Policy", href: "/privacy" },
  { label: "Terms of Use", href: "/terms" },
];

const SOCIALS = [
  { label: "Facebook", href: "https://facebook.com", Icon: Facebook },
  { label: "Instagram", href: "https://instagram.com", Icon: Instagram },
  { label: "Twitter", href: "https://twitter.com", Icon: Twitter },
];

export function SiteFooter() {
  return (
    <>
      {/* "i am Kolkata" mark sitting on the cream band above the footer
          (Figma 49:2160 on the homepage, 95:429 on the submission page). */}
      <div className="w-full bg-cream">
        <div className="mx-auto max-w-[1440px] px-20 pb-5">
          <Asset src={IMG.logoIAmKolkata} alt="I am Kolkata" className="h-[94px] w-[150px] object-contain" />
        </div>
      </div>

      <footer className="relative w-full bg-pink">
      <div className="mx-auto max-w-[1440px] px-20">
        <Asset src={IMG.logoToi} alt="The Times of India" className="h-[74px] w-[290px] object-contain pt-2" />

        <div className="flex items-start justify-between pt-[13px] pb-[34px]">
          <p className="w-[360px] font-body text-[14px] leading-[1.6] text-white/80">
            Amar Para 2.0 is a citizen-driven community initiative celebrating local stories,
            neighborhoods, food stalls, and the unique, unmatched heritage of Kolkata.
          </p>

          <div className="flex w-[634px] items-start justify-between font-body text-[14px] text-white">
            <div className="flex flex-1 gap-4">
              {COLUMN_ONE.map((link) => (
                <Link key={link.label} href={link.href} className="opacity-80 hover:opacity-100">
                  {link.label}
                </Link>
              ))}
            </div>
            <div className="flex flex-1 gap-4">
              {COLUMN_TWO.map((link) => (
                <Link key={link.label} href={link.href} className="opacity-80 hover:opacity-100">
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="flex gap-4 pb-8">
          {SOCIALS.map(({ label, href, Icon }) => (
            <a
              key={label}
              href={href}
              aria-label={label}
              target="_blank"
              rel="noreferrer"
              className="flex size-10 items-center justify-center rounded-full border border-white text-white transition-colors hover:bg-white hover:text-pink"
            >
              <Icon />
            </a>
          ))}
        </div>
      </div>
      </footer>
    </>
  );
}
