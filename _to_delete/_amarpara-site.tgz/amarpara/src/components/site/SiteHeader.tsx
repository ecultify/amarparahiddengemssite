"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Button3D } from "@/components/ui/Button3D";
import { Asset } from "@/components/ui/Asset";
import { IMG } from "@/lib/assets";

const NAV = [
  { label: "Home", href: "/" },
  { label: "500 Gems", href: "/500-gems" },
  { label: "Stories", href: "/#stories" },
  { label: "Creator Trails", href: "/#creator-trails" },
  { label: "Participate", href: "/participate" },
  { label: "About", href: "/about" },
  { label: "FAQs", href: "/faqs" },
];

export function SiteHeader() {
  const pathname = usePathname();

  const isActive = (href: string) => {
    // In-page anchors (Stories, Creator Trails) never take the active state.
    if (href.startsWith("/#")) return false;
    if (href === "/") return pathname === "/";
    return pathname.startsWith(href);
  };

  return (
    <header className="sticky top-0 z-50 h-[88px] w-full border-b-2 border-line bg-cream">
      <div className="mx-auto flex h-full max-w-[1440px] items-center justify-between px-20">
        <Link href="/" className="flex items-center gap-3">
          <Asset src={IMG.logoMark} alt="Amar Para 2.0" className="size-10 shrink-0" />
          <span className="flex flex-col gap-[2px] leading-none">
            <span className="font-display text-[18px] font-black text-navy">AMAR PARA 2.0</span>
            <span className="font-ui text-[10px] font-extrabold tracking-[0.04em] text-red">
              THE TIMES OF INDIA
            </span>
          </span>
        </Link>

        <nav className="flex items-center gap-8">
          {NAV.map((item) => {
            const active = isActive(item.href);
            return (
              <Link
                key={item.label}
                href={item.href}
                className="flex flex-col items-start justify-center gap-1"
              >
                <span
                  className={
                    active
                      ? "font-ui text-[15px] font-extrabold text-red"
                      : "font-ui text-[15px] font-semibold text-navy hover:text-red"
                  }
                >
                  {item.label}
                </span>
                {active ? <span className="h-[2px] w-4 rounded-[1px] bg-red" /> : null}
              </Link>
            );
          })}
        </nav>

        <Button3D href="/submit" size="sm">
          Submit your gem
        </Button3D>
      </div>
    </header>
  );
}
