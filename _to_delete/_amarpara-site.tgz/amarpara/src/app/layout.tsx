import type { Metadata } from "next";
// Self-hosted via Fontsource so the build has no network dependency on Google
// Fonts. Weights match the Figma type styles: Outfit 400-900 (display),
// Manrope 400-800 (UI), Fira Sans 400 (body copy).
import "@fontsource-variable/outfit";
import "@fontsource-variable/manrope";
import "@fontsource/fira-sans/400.css";
import "@fontsource/fira-sans/500.css";
import "./globals.css";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";

export const metadata: Metadata = {
  title: "Amar Para 2.0 — 500 Gems. One Kolkata.",
  description:
    "A citizen-driven Times of India initiative mapping 500 hidden gems across Kolkata's paras: the food, the places, the traditions and the people.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-cream antialiased">
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
