import { Asset } from "@/components/ui/Asset";
import { GemsDiscovered } from "@/components/gems/GemsDiscovered";
import { SubmissionForm } from "@/components/gems/SubmissionForm";
import { IMG } from "@/lib/assets";

/** Share Your Para's Hidden Gem — Figma node 95:309 (entry-submission-page). */
export default function SubmitPage() {
  return (
    <>
      <section className="relative w-full overflow-hidden bg-cream px-[120px] pt-20 pb-[100px]">
        <Asset
          src={IMG.accentArch}
          className="pointer-events-none absolute top-[200px] right-[-13px] h-[220px] w-[130px] object-contain opacity-[0.88]"
        />
        <Asset
          src={IMG.accentArch}
          className="pointer-events-none absolute top-[200px] left-[-16px] h-[220px] w-[130px] scale-x-[-1] object-contain opacity-[0.88]"
        />
        <Asset
          src={IMG.accentStatue}
          className="pointer-events-none absolute bottom-[-40px] left-[-66px] h-[280px] w-[180px] object-contain opacity-[0.88]"
        />
        <Asset
          src={IMG.accentTemple}
          className="pointer-events-none absolute right-0 bottom-[-40px] h-[280px] w-[180px] scale-x-[-1] object-contain opacity-85"
        />

        <div className="relative mx-auto flex max-w-[1200px] flex-col items-center gap-12">
          <div className="flex w-[840px] flex-col items-center gap-4">
            <span className="rounded-full bg-pink/8 px-3.5 py-1.5 font-display text-[14px] font-extrabold uppercase tracking-[0.06em] text-pink">
              Submit your entry
            </span>
            <h1 className="text-center font-display text-[48px] leading-tight font-black text-navy">
              Share Your Para&apos;s Hidden Gem
            </h1>
            <p className="text-center font-body text-[18px] leading-[28px] text-slate">
              Tell us about the special places, stories, and memories that make your neighborhood
              unique. Stand up for your community and place your neighborhood&apos;s legacy on
              TOI&apos;s historic directory.
            </p>
          </div>

          <SubmissionForm />
        </div>
      </section>

      <GemsDiscovered theme="cyan" />
    </>
  );
}
