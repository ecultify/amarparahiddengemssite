import { Asset } from "@/components/ui/Asset";
import { Button3D } from "@/components/ui/Button3D";
import { GemsDiscovered } from "@/components/gems/GemsDiscovered";
import { User, MapPin, Upload, Check } from "@/components/ui/icons";
import { IMG } from "@/lib/assets";

/** Participate — Figma node 95:4 (submit-your-gem-final). */

const STEPS = [
  {
    n: 1,
    Icon: User,
    title: "Login",
    body: "Sign in with SSO securely with your mobile number and one-time OTP verification.",
  },
  {
    n: 2,
    Icon: MapPin,
    title: "Share Your Gem",
    body: "Tell us about your neighborhood's sweet shop, old building, custom, or unsung hero.",
  },
  {
    n: 3,
    Icon: Upload,
    title: "Upload & Submit",
    body: "Attach a clear, stunning photograph or 30-sec video clip, then submit for TOI's review.",
  },
];

const GUIDELINES = [
  "Your gem must be a real place, street, food stall, building, or story from Kolkata.",
  "Upload clear photos - avoid blurry, out-of-focus, or irrelevant stock images.",
  "All entries are reviewed - only genuine, original citizen-led submissions will be published.",
  "Be respectful and authentic - celebrate your para with genuine pride and verified local historical context.",
  "Multiple submissions are welcome - explore and nominate all the cultural diamonds in your neighborhood!",
];

function Connector() {
  return (
    <div className="relative flex size-[72px] shrink-0 items-center justify-center">
      <span className="h-[2px] w-14 rounded-full bg-white/20" />
      <span className="absolute size-3 rotate-45 border-2 border-white/20 bg-green-soft" />
    </div>
  );
}

export default function ParticipatePage() {
  return (
    <>
      {/* Section-Hero-Login — Figma 95:35 */}
      <section className="relative flex h-[516px] w-full items-center overflow-hidden bg-cream px-20">
        <Asset
          src={IMG.accentStatue}
          className="pointer-events-none absolute top-[244px] left-[-66px] h-[280px] w-[180px] object-contain opacity-[0.88]"
        />
        <Asset
          src={IMG.accentTemple}
          className="pointer-events-none absolute top-[244px] right-0 h-[280px] w-[180px] scale-x-[-1] object-contain opacity-85"
        />
        <Asset
          src={IMG.accentAuto}
          className="pointer-events-none absolute top-[417px] right-[139px] h-[107px] w-[142px] object-contain opacity-15"
        />

        <div className="relative mx-auto flex w-full max-w-[1315px] flex-col items-center gap-8">
          <div className="flex flex-col items-center gap-4 text-center">
            <h1 className="font-display text-[72px] leading-[72px] font-black text-navy">
              500 Gems.
              <br />
              One Kolkata.
            </h1>
            <p className="font-body text-[24px] leading-[36px] font-medium text-red">
              Share Your Para&apos;s Hidden Gem
            </p>
            <p className="w-[937px] font-body text-[16px] leading-[26px] text-slate">
              Kolkata is a mosaic of untold stories, legendary sweet shops, heritage corners, and local
              icons. Stand up for your neighborhood and place your para on the map. Log in with your
              mobile number to begin.
            </p>
          </div>

          <Button3D href="/submit" variant="red" className="h-16">
            Log in to participate
          </Button3D>
        </div>
      </section>

      {/* Section-How-To-Participate — Figma 95:46 */}
      <section className="relative w-full overflow-hidden bg-green px-20 pt-[53px] pb-[100px]">
        <Asset
          src={IMG.accentStatue}
          className="pointer-events-none absolute top-[547px] left-[-56px] h-[280px] w-[180px] object-contain opacity-[0.88]"
        />
        <Asset
          src={IMG.accentTemple}
          className="pointer-events-none absolute top-[519px] right-0 h-[300px] w-[180px] scale-x-[-1] object-contain opacity-85"
        />

        <div className="relative mx-auto flex max-w-[1280px] flex-col items-center gap-[59px]">
          <div className="flex w-full flex-col items-center gap-8">
            <div className="flex w-[800px] flex-col items-center gap-3 text-center">
              <p className="font-display text-[14px] font-black uppercase tracking-[0.08em] text-pink">
                Step-by-step guide
              </p>
              <h2 className="font-display text-[42px] leading-tight font-black text-white">
                How to Participate
              </h2>
              <p className="font-body text-[18px] leading-[28px] text-white">
                Put your neighborhood&apos;s legacy on Kolkata&apos;s mapping directory in three simple steps.
              </p>
            </div>

            <div className="flex w-full items-start justify-center gap-6">
              {STEPS.map((step, index) => (
                <div key={step.n} className="contents">
                  {index > 0 ? <Connector /> : null}
                  <div className="flex flex-1 flex-col items-center gap-3">
                    <div className="relative flex size-[72px] items-center justify-center rounded-full border-[3px] border-red bg-white text-navy">
                      <step.Icon className="size-7" />
                      <span className="absolute -top-[7px] -right-[7px] flex size-7 items-center justify-center rounded-full bg-red font-display text-[14px] font-extrabold text-white">
                        {step.n}
                      </span>
                    </div>
                    <div className="flex flex-col items-center gap-1.5 text-center text-white">
                      <h3 className="font-display text-[18px] font-extrabold">{step.title}</h3>
                      <p className="font-body text-[14px] leading-[1.5] opacity-90">{step.body}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* submission-guidelines — Figma 95:88 */}
          <div className="flex w-full items-start gap-12">
            <div className="flex w-[360px] flex-col gap-3">
              <p className="font-display text-[14px] font-black uppercase tracking-[0.08em] text-pink">
                Important notes
              </p>
              <h2 className="font-display text-[42px] leading-tight font-black text-white">
                Submission Guidelines
              </h2>
            </div>

            <div className="grid flex-1 grid-cols-2 gap-4">
              {GUIDELINES.map((text) => (
                <div
                  key={text}
                  className="flex h-20 items-center gap-3 rounded-[16px] border border-white/40 bg-white/80 p-4 shadow-[0_10px_24px_0_rgba(27,42,74,0.08)]"
                >
                  <span className="flex size-6 shrink-0 items-center justify-center rounded-[12px] bg-green-soft/15 text-green-soft">
                    <Check />
                  </span>
                  <p className="font-body text-[14px] leading-[1.5] text-navy">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <GemsDiscovered theme="cream" />
    </>
  );
}
