import { Hero } from "@/components/home/Hero";
import { ExploreGems } from "@/components/home/ExploreGems";
import { StoriesFromParas } from "@/components/home/StoriesFromParas";
import { ArticlesFeatures } from "@/components/home/ArticlesFeatures";
import { CreatorTrails } from "@/components/home/CreatorTrails";

/** Homepage — Figma node 49:1939 (amar-para-homepage - final). */
export default function HomePage() {
  return (
    <>
      <Hero />
      <ExploreGems />
      <StoriesFromParas />
      <ArticlesFeatures />
      <CreatorTrails />
    </>
  );
}
