import { Asset } from "@/components/ui/Asset";
import { Button3D } from "@/components/ui/Button3D";
import { MapPin } from "@/components/ui/icons";
import { GALLERY_IMG } from "@/lib/assets";
import {
  GEM_COUNT,
  PHOTO_GEMS,
  STREET_STORIES,
  VIDEO_GEMS,
  type GalleryGem,
} from "@/data/site";

/** 500 Gems of Kolkata — Figma node 106:272 (gallery-page-final). */

function GemMeta({ gem }: { gem: GalleryGem }) {
  return (
    <div className="flex min-h-0 flex-1 flex-col justify-between p-5">
      <div className="flex flex-col items-start gap-1.5">
        <span
          className={`inline-flex rounded-[6px] px-[10px] py-[4px] font-ui text-[11px] font-bold uppercase ${gem.categoryClass}`}
        >
          {gem.category}
        </span>
        <h3 className="font-display text-[18px] leading-tight font-black text-navy">{gem.title}</h3>
      </div>
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <MapPin className="size-3.5 shrink-0 text-pink" />
          <span className="font-ui text-[13px] font-semibold text-slate">{gem.location}</span>
        </div>
        <span className="font-ui text-[13px] font-semibold text-grey">
          Submitted by: {gem.submittedBy}
        </span>
      </div>
    </div>
  );
}

function PhotoCard({ gem }: { gem: GalleryGem }) {
  return (
    <article className="flex h-[320px] w-[304px] shrink-0 flex-col overflow-hidden rounded-[8px] bg-cream shadow-[0_8px_16px_0_rgba(27,42,74,0.07)]">
      <Asset src={gem.image} alt={gem.title} className="h-[180px] w-full shrink-0 object-cover" />
      <GemMeta gem={gem} />
    </article>
  );
}

function VideoCard({ gem }: { gem: GalleryGem }) {
  return (
    <article className="flex h-[360px] w-[628px] shrink-0 flex-col overflow-hidden rounded-[8px] bg-cream shadow-[0_8px_16px_0_rgba(27,42,74,0.07)]">
      <div className="relative flex h-[180px] w-full items-center justify-center">
        <Asset src={gem.image} alt={gem.title} className="absolute inset-0 size-full object-cover" />
        <button
          type="button"
          aria-label={`Play ${gem.title}`}
          className="btn-3d relative flex size-12 items-center justify-center rounded-full bg-yellow text-navy"
        >
          <svg viewBox="0 0 24 24" className="size-4" fill="currentColor" aria-hidden>
            <path d="M8 5v14l11-7z" />
          </svg>
        </button>
      </div>
      <GemMeta gem={gem} />
    </article>
  );
}

export default function GalleryPage() {
  const percent = Math.round((GEM_COUNT.discovered / GEM_COUNT.total) * 100);

  return (
    <>
      {/* gallery-hero-section — Figma 106:288 */}
      <section className="relative flex w-full flex-col items-center gap-10 overflow-hidden bg-white p-20">
        <Asset
          src={GALLERY_IMG.accentKite}
          className="pointer-events-none absolute top-10 left-[-30px] h-[170px] w-[150px] object-contain opacity-80"
        />
        <Asset
          src={GALLERY_IMG.accentHandRickshaw}
          className="pointer-events-none absolute top-[60px] right-[-20px] h-[160px] w-[190px] object-contain opacity-85"
        />

        <div className="relative flex w-[800px] flex-col items-center gap-4">
          <p className="font-display text-[14px] font-black uppercase tracking-[0.08em] text-pink">
            Community Gallery
          </p>
          <h1 className="text-center font-display text-[56px] leading-tight font-black text-navy">
            500 Gems of Kolkata
          </h1>
          <p className="text-center font-body text-[18px] leading-[1.6] text-slate">
            Welcome to the living archive of our city. Discover, wander, and celebrate the beautiful
            architectural nooks, local tea joints, and cultural cornerstones suggested and documented
            by citizens.
          </p>
        </div>

        <div className="relative flex w-[400px] flex-col items-center gap-3">
          <div className="flex w-full items-start justify-between text-[14px]">
            <span className="font-ui font-extrabold text-navy">
              {GEM_COUNT.discovered} GEMS DISCOVERED
            </span>
            <span className="font-ui font-bold text-grey">Goal: {GEM_COUNT.total}</span>
          </div>
          <div className="h-4 w-full overflow-hidden rounded-full bg-line">
            <div className="h-full rounded-full bg-pink" style={{ width: `${percent}%` }} />
          </div>
        </div>
      </section>

      {/* bento-gallery-section — Figma 106:316 */}
      <section className="flex w-full flex-col items-center gap-8 bg-white px-20 pt-20 pb-[100px]">
        <div className="flex w-full max-w-[1280px] flex-col gap-6">
          <header className="flex flex-col gap-2">
            <p className="font-display text-[14px] font-black uppercase tracking-[0.08em] text-pink">
              Photo Gems
            </p>
            <h2 className="font-display text-[32px] font-black text-navy">Captured Moments</h2>
          </header>
          <div className="grid grid-cols-[repeat(auto-fit,304px)] gap-6">
            {PHOTO_GEMS.map((gem) => (
              <PhotoCard key={gem.title} gem={gem} />
            ))}
          </div>
        </div>

        <div className="flex w-full max-w-[1280px] flex-col gap-6 bg-butter py-8">
          <header className="flex flex-col gap-2">
            <p className="font-display text-[14px] font-black uppercase tracking-[0.08em] text-pink">
              Video Stories
            </p>
            <h2 className="font-display text-[32px] font-black text-navy">Moving Memories</h2>
          </header>
          <div className="flex gap-6">
            {VIDEO_GEMS.map((gem) => (
              <VideoCard key={gem.title} gem={gem} />
            ))}
          </div>
        </div>

        <div className="flex w-full max-w-[1280px] flex-col gap-6 bg-navy py-8">
          <header className="flex flex-col gap-2">
            <p className="font-display text-[14px] font-black uppercase tracking-[0.08em] text-yellow">
              Written Tales
            </p>
            <h2 className="font-display text-[32px] font-black text-white">
              Stories from the Streets
            </h2>
          </header>
          <div className="flex gap-6">
            {STREET_STORIES.map((story) => (
              <article
                key={story.title}
                className={`flex h-[360px] w-[304px] shrink-0 flex-col justify-between rounded-[8px] border p-6 shadow-[0_8px_8px_rgba(27,42,74,0.07)] ${story.card}`}
              >
                <div className="flex flex-col gap-3">
                  <span className={`font-display text-[48px] leading-[20px] font-black ${story.mark}`}>
                    &ldquo;
                  </span>
                  <p className="font-display text-[16px] leading-[1.5] font-semibold text-navy">
                    {story.quote}
                  </p>
                </div>
                <div className="flex flex-col gap-1">
                  <h3 className="font-display text-[16px] font-black text-navy">{story.title}</h3>
                  <p className="font-ui text-[13px] font-semibold text-grey">{story.meta}</p>
                </div>
              </article>
            ))}
          </div>
        </div>

        <Button3D href="/500-gems" className="rounded-[8px]">
          Load more gems
        </Button3D>
      </section>

      {/* cta-submit-section — Figma 106:420 */}
      <section className="relative flex w-full flex-col items-center justify-center gap-8 overflow-hidden bg-green-soft px-20 py-[120px]">
        <Asset
          src={GALLERY_IMG.accentMonument}
          className="pointer-events-none absolute top-[60px] left-[-40px] h-[280px] w-[180px] object-contain opacity-80"
        />
        <Asset
          src={GALLERY_IMG.accentTempleGreen}
          className="pointer-events-none absolute top-20 right-[-30px] h-[280px] w-[180px] object-contain opacity-80"
        />
        <h2 className="relative text-center font-display text-[48px] font-black text-black">
          Your Para Has a Story Too
        </h2>
        <p className="relative w-[680px] text-center font-body text-[18px] leading-[1.5] text-cream">
          Don&apos;t let the unique history of your street fade away. Document your local addas,
          favorite sweet shops, or historic landmarks and share it with the world.
        </p>
        <Button3D href="/submit" className="relative rounded-[8px]">
          Submit your gem
        </Button3D>
      </section>
    </>
  );
}
