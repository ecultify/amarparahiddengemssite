/**
 * Every image in the design lives in /public/images and is downloaded by
 * `npm run assets` from figma-assets.json. Reference images through this map so
 * a renamed or missing asset is a compile error rather than a silent 404.
 */
export const IMG = {
  heroCollage: "/images/hero-collage.png",

  accentKites: "/images/accent-kites.png",
  accentStatue: "/images/accent-statue.png",
  accentTemple: "/images/accent-temple.png",
  accentBirds: "/images/accent-birds.png",
  accentArch: "/images/accent-arch.png",
  accentGolfer: "/images/accent-golfer.png",
  accentKiteCreator: "/images/accent-kite-creator.png",
  accentAuto: "/images/accent-auto.png",
  accentAutoRickshaw: "/images/accent-auto-rickshaw.png",
  accentHeritageWatermark: "/images/accent-heritage-watermark.png",

  logoToi: "/images/logo-toi.png",
  logoIAmKolkata: "/images/logo-i-am-kolkata.png",
  logoMark: "/images/logo-mark.svg",
} as const;

/** Gallery page (Figma 106:272) artwork. */
export const GALLERY_IMG = {
  accentKite: "/images/accent-kite-gallery.png",
  accentHandRickshaw: "/images/accent-hand-rickshaw.png",
  accentMonument: "/images/accent-monument.png",
  accentTempleGreen: "/images/accent-temple-green.png",
} as const;
